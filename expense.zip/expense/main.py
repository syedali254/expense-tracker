# main.py
from tkinter import *
from tkinter import messagebox
import sqlite3
import winsound  # Optional: Provides sound feedback on Windows systems; remove if not applicable
import matplotlib.pyplot as plt  # Imported for data visualization with pie charts

# Global variable to store the ID of the currently logged-in user
current_user_id = None

def login_window():
    # Initializes the login window for user authentication
    global entry_username, entry_password, root
    root = Tk()
    root.title("Expense Tracker - Login")
    root.geometry("300x250")
    root.configure(bg="#f0f0f0")

    Label(root, text="Username", bg="#f0f0f0").pack(pady=5)
    entry_username = Entry(root)
    entry_username.pack(pady=5)
    Label(root, text="Password", bg="#f0f0f0").pack(pady=5)
    entry_password = Entry(root, show="*")
    entry_password.pack(pady=5)
    
    Button(root, text="Login", bg="#2196F3", fg="white", command=check_login).pack(pady=10)
    Button(root, text="Create Account", bg="#4CAF50", fg="white", command=create_account_window).pack(pady=10)
    
    root.mainloop()

def check_login():
    # Verifies user credentials against the database
    username = entry_username.get()
    password = entry_password.get()
    conn = sqlite3.connect("expense_tracker.db")
    cursor = conn.cursor() #cursor to execute queries
    cursor.execute("SELECT id FROM User WHERE username=? AND password=?", (username, password))
    result = cursor.fetchone()
    conn.close()

    if result:
        global current_user_id
        current_user_id = result[0]
        root.destroy()
        main_window(username)
    else:
        messagebox.showerror("Error", "Invalid username or password")

def create_account_window():
    # Opens a new window for user registration
    create_window = Toplevel()
    create_window.title("Create Account")
    create_window.geometry("300x200")
    create_window.configure(bg="#f0f0f0")

    Label(create_window, text="New Username", bg="#f0f0f0").pack(pady=5)
    entry_new_username = Entry(create_window)
    entry_new_username.pack(pady=5)
    Label(create_window, text="New Password", bg="#f0f0f0").pack(pady=5)
    entry_new_password = Entry(create_window, show="*")
    entry_new_password.pack(pady=5)
    
    Button(create_window, text="Register", bg="#4CAF50", fg="white", 
           command=lambda: create_account(entry_new_username.get(), entry_new_password.get(), create_window)).pack(pady=20)

def create_account(username, password, window):
    # Handles the creation of a new user account in the database
    if not username or not password:
        messagebox.showerror("Error", "Please fill all fields")
        return
    
    conn = sqlite3.connect("expense_tracker.db")
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO User (username, password) VALUES (?, ?)", (username, password))
        conn.commit()
        messagebox.showinfo("Success", "Account created! You can now log in.")
        window.destroy()
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "Username already exists. Try a different one.")
    finally:
        conn.close()

def main_window(username):
    # Displays the main application interface for tracking expenses and income
    app = Tk()
    app.title("Expense Tracker")
    app.geometry("400x500")
    app.configure(bg="#f0f0f0")
    Label(app, text=f"Welcome, {username}!", font=("Arial", 16, "bold"), bg="#f0f0f0").pack(pady=10)

    # Frame for adding expenses with a light blue background
    expense_frame = Frame(app, bg="#d9e6ff", padx=10, pady=10)
    expense_frame.pack(pady=10)
    Label(expense_frame, text="Add Expense", font=("Arial", 14, "bold"), bg="#d9e6ff").pack()
    Label(expense_frame, text="Category", bg="#d9e6ff").pack()
    entry_category = Entry(expense_frame)
    entry_category.pack()
    Label(expense_frame, text="Amount", bg="#d9e6ff").pack()
    entry_expense_amount = Entry(expense_frame)
    entry_expense_amount.pack()
    Button(expense_frame, text="Add Expense", bg="#4CAF50", fg="white", command=lambda: add_expense(entry_category.get(), entry_expense_amount.get())).pack(pady=5)

    # Frame for adding income with a light red background
    income_frame = Frame(app, bg="#ffe6e6", padx=10, pady=10)
    income_frame.pack(pady=10)
    Label(income_frame, text="Add Income", font=("Arial", 14, "bold"), bg="#ffe6e6").pack()
    Label(income_frame, text="Amount", bg="#ffe6e6").pack()
    entry_income_amount = Entry(income_frame)
    entry_income_amount.pack()
    Label(income_frame, text="Source", bg="#ffe6e6").pack()
    entry_source = Entry(income_frame)
    entry_source.pack()
    Button(income_frame, text="Add Income", bg="#2196F3", fg="white", command=lambda: add_income(entry_income_amount.get(), entry_source.get())).pack(pady=5)

    # Button to view transaction history
    Button(app, text="View Transaction History", bg="#FF9800", fg="white", font=("Arial", 10, "bold"), command=show_history).pack(pady=10)
    # Button to display expense and income visualizations
    Button(app, text="Show Visualizations", bg="#9C27B0", fg="white", font=("Arial", 10, "bold"), command=show_visualizations).pack(pady=10)
    # Button to log out and return to login screen
    Button(app, text="Logout", bg="#F44336", fg="white", font=("Arial", 10, "bold"), command=lambda: [app.destroy(), login_window()]).pack(pady=10)

    app.mainloop()

def add_expense(category, amount):
    # Adds a new expense entry to the database
    if not category or not amount:
        messagebox.showerror("Error", "Please fill all fields")
        return
    try:
        amount = float(amount)
        conn = sqlite3.connect("expense_tracker.db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Expenses (user_id, category, date, amount, description) VALUES (?, ?, date('now'), ?, ?)",
                       (current_user_id, category, amount, "Added via app"))
        conn.commit()
        conn.close()
        winsound.Beep(1000, 200)  # Optional: Audio feedback for successful addition (Windows only)
        messagebox.showinfo("Success", "Expense added!")
    except ValueError:
        messagebox.showerror("Error", "Amount must be a number")

def add_income(amount, source):
    # Adds a new income entry to the database
    if not amount or not source:
        messagebox.showerror("Error", "Please fill all fields")
        return
    try:
        amount = float(amount)
        conn = sqlite3.connect("expense_tracker.db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Income (user_id, amount, date, source) VALUES (?, ?, date('now'), ?)",
                       (current_user_id, amount, source))
        conn.commit()
        conn.close()
        winsound.Beep(1500, 200)  # Optional: Audio feedback for successful addition (Windows only)
        messagebox.showinfo("Success", "Income added!")
    except ValueError:
        messagebox.showerror("Error", "Amount must be a number")

def show_history():
    # Displays the user’s transaction history in PKR
    history_window = Toplevel()
    history_window.title("Transaction History")
    history_window.geometry("500x400")
    history_window.configure(bg="#f0f0f0")

    canvas = Canvas(history_window, bg="#f0f0f0")
    scrollbar = Scrollbar(history_window, orient="vertical", command=canvas.yview)
    scrollable_frame = Frame(canvas, bg="#f0f0f0")

    scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    conn = sqlite3.connect("expense_tracker.db")
    cursor = conn.cursor()

    cursor.execute("SELECT category, date, amount, description FROM Expenses WHERE user_id=?", (current_user_id,))
    expenses = cursor.fetchall()
    Label(scrollable_frame, text="Expenses", font=("Arial", 12, "bold"), bg="#f0f0f0").pack(pady=5)
    for exp in expenses:
        Label(scrollable_frame, text=f"{exp[1]} | {exp[0]} | PKR {exp[2]:.2f} | {exp[3]}", bg="#ffebee", fg="#d32f2f").pack(fill="x", padx=5, pady=2)

    cursor.execute("SELECT amount, date, source FROM Income WHERE user_id=?", (current_user_id,))
    incomes = cursor.fetchall()
    Label(scrollable_frame, text="Income", font=("Arial", 12, "bold"), bg="#f0f0f0").pack(pady=5)
    for inc in incomes:
        Label(scrollable_frame, text=f"{inc[1]} | PKR {inc[0]:.2f} | {inc[2]}", bg="#e8f5e9", fg="#2e7d32").pack(fill="x", padx=5, pady=2)

    conn.close()
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

def show_visualizations():
    # Generates pie charts for expense breakdown by category and income by source
    conn = sqlite3.connect("expense_tracker.db")
    cursor = conn.cursor()

    # Fetch expense data grouped by category
    cursor.execute("SELECT category, SUM(amount) FROM Expenses WHERE user_id=? GROUP BY category", (current_user_id,))
    expense_data = cursor.fetchall()
    
    # Fetch income data grouped by source
    cursor.execute("SELECT source, SUM(amount) FROM Income WHERE user_id=? GROUP BY source", (current_user_id,))
    income_data = cursor.fetchall()

    conn.close()

    # Process expense data for pie chart
    if expense_data:
        expense_categories, expense_amounts = zip(*expense_data)
        plt.figure(figsize=(8, 5))
        plt.pie(expense_amounts, labels=expense_categories, autopct='%1.1f%%', startangle=90)
        plt.title("Expense Breakdown by Category (PKR)")
        plt.axis('equal')  # Ensures pie chart is circular
        plt.show()
    else:
        messagebox.showinfo("Info", "No expenses recorded yet for visualization.")

    # Process income data for pie chart
    if income_data:
        income_sources, income_amounts = zip(*income_data)
        plt.figure(figsize=(8, 5))
        plt.pie(income_amounts, labels=income_sources, autopct='%1.1f%%', startangle=90)
        plt.title("Income Breakdown by Source (PKR)")
        plt.axis('equal')
        plt.show()
    else:
        messagebox.showinfo("Info", "No income recorded yet for visualization.")

if __name__ == "__main__":
    login_window()  # Entry point: Launches the application