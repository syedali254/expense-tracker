# database.py
import sqlite3

def create_database():
    conn = sqlite3.connect("expense_tracker.db")
    cursor = conn.cursor()

    # Create User table
    cursor.execute('''CREATE TABLE IF NOT EXISTS User (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )''')

    # Create Expenses table
    cursor.execute('''CREATE TABLE IF NOT EXISTS Expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        category TEXT,
        date TEXT,
        amount REAL,
        description TEXT,
        FOREIGN KEY (user_id) REFERENCES User(id)
    )''')

    # Create Income table
    cursor.execute('''CREATE TABLE IF NOT EXISTS Income (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        amount REAL,
        date TEXT,
        source TEXT,
        FOREIGN KEY (user_id) REFERENCES User(id)
    )''')

    # Insert a default user for testing (username: "test", password: "1234")
    cursor.execute("INSERT OR IGNORE INTO User (username, password) VALUES (?, ?)", ("test", "1234"))
    
    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_database()